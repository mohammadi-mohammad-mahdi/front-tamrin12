﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParentChild
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void itmExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void itmNew_Click(object sender, EventArgs e)
        {
            frmChild frmNew = new frmChild();
            frmNew.MdiParent = this;
            frmNew.Text = "New Document";
            frmNew.Show();

        }

        private void itmCascade_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void itmHorizontal_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void itmVertical_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);

        }

        private void itmArrangIcons_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void itmSaveAS_Click(object sender, EventArgs e)
        {
            dlgSaveAs.ShowDialog();
            frmChild child = (frmChild)this.ActiveMdiChild;

            System.IO.File.WriteAllText(dlgSaveAs.FileName, child.txtMain.Text);
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
                        frmChild child = (frmChild)this.ActiveMdiChild;

                        Clipboard.SetText(child.txtMain.SelectedText);
                        child.txtMain.SelectedText = "";
        }

        private void pastToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmChild child = (frmChild)this.ActiveMdiChild;

            child.txtMain.SelectedText = Clipboard.GetText();
        
        }
    }
}
