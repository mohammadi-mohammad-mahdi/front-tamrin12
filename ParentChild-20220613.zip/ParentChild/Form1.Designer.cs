﻿namespace ParentChild
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.itmNew = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileLineOne = new System.Windows.Forms.ToolStripSeparator();
            this.itmExit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuWindows = new System.Windows.Forms.ToolStripMenuItem();
            this.itmCascade = new System.Windows.Forms.ToolStripMenuItem();
            this.itmHorizontal = new System.Windows.Forms.ToolStripMenuItem();
            this.itmVertical = new System.Windows.Forms.ToolStripMenuItem();
            this.itmArrangIcons = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.itmSaveAS = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.dlgSaveAs = new System.Windows.Forms.SaveFileDialog();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pastToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.toolStripMenuItem2,
            this.mnuWindows});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.MdiWindowListItem = this.mnuWindows;
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(659, 24);
            this.mnuMain.TabIndex = 1;
            this.mnuMain.Text = "Main";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itmNew,
            this.toolStripMenuItem3,
            this.itmSaveAS,
            this.mnuFileLineOne,
            this.itmExit});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(37, 20);
            this.mnuFile.Text = "&File";
            // 
            // itmNew
            // 
            this.itmNew.Name = "itmNew";
            this.itmNew.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.itmNew.Size = new System.Drawing.Size(152, 22);
            this.itmNew.Text = "&New";
            this.itmNew.Click += new System.EventHandler(this.itmNew_Click);
            // 
            // mnuFileLineOne
            // 
            this.mnuFileLineOne.Name = "mnuFileLineOne";
            this.mnuFileLineOne.Size = new System.Drawing.Size(149, 6);
            // 
            // itmExit
            // 
            this.itmExit.Name = "itmExit";
            this.itmExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.itmExit.Size = new System.Drawing.Size(152, 22);
            this.itmExit.Text = "E&xit";
            this.itmExit.Click += new System.EventHandler(this.itmExit_Click);
            // 
            // mnuWindows
            // 
            this.mnuWindows.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itmCascade,
            this.itmHorizontal,
            this.itmVertical,
            this.itmArrangIcons,
            this.toolStripMenuItem1});
            this.mnuWindows.Name = "mnuWindows";
            this.mnuWindows.Size = new System.Drawing.Size(68, 20);
            this.mnuWindows.Text = "&Windows";
            // 
            // itmCascade
            // 
            this.itmCascade.Name = "itmCascade";
            this.itmCascade.Size = new System.Drawing.Size(152, 22);
            this.itmCascade.Text = "Cascade";
            this.itmCascade.Click += new System.EventHandler(this.itmCascade_Click);
            // 
            // itmHorizontal
            // 
            this.itmHorizontal.Name = "itmHorizontal";
            this.itmHorizontal.Size = new System.Drawing.Size(152, 22);
            this.itmHorizontal.Text = "Horizontal";
            this.itmHorizontal.Click += new System.EventHandler(this.itmHorizontal_Click);
            // 
            // itmVertical
            // 
            this.itmVertical.Name = "itmVertical";
            this.itmVertical.Size = new System.Drawing.Size(152, 22);
            this.itmVertical.Text = "Vertical";
            this.itmVertical.Click += new System.EventHandler(this.itmVertical_Click);
            // 
            // itmArrangIcons
            // 
            this.itmArrangIcons.Name = "itmArrangIcons";
            this.itmArrangIcons.Size = new System.Drawing.Size(152, 22);
            this.itmArrangIcons.Text = "Arrange Icons";
            this.itmArrangIcons.Click += new System.EventHandler(this.itmArrangIcons_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(149, 6);
            // 
            // itmSaveAS
            // 
            this.itmSaveAS.Name = "itmSaveAS";
            this.itmSaveAS.Size = new System.Drawing.Size(152, 22);
            this.itmSaveAS.Text = "Save AS";
            this.itmSaveAS.Click += new System.EventHandler(this.itmSaveAS_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(149, 6);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pastToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(39, 20);
            this.toolStripMenuItem2.Text = "&Edit";
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cutToolStripMenuItem.Text = "&Cut";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.cutToolStripMenuItem_Click);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.copyToolStripMenuItem.Text = "&Copy";
            // 
            // pastToolStripMenuItem
            // 
            this.pastToolStripMenuItem.Name = "pastToolStripMenuItem";
            this.pastToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pastToolStripMenuItem.Text = "&Past";
            this.pastToolStripMenuItem.Click += new System.EventHandler(this.pastToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 473);
            this.Controls.Add(this.mnuMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mnuMain;
            this.Name = "frmMain";
            this.Text = "Samples";
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem itmNew;
        private System.Windows.Forms.ToolStripSeparator mnuFileLineOne;
        private System.Windows.Forms.ToolStripMenuItem itmExit;
        private System.Windows.Forms.ToolStripMenuItem mnuWindows;
        private System.Windows.Forms.ToolStripMenuItem itmCascade;
        private System.Windows.Forms.ToolStripMenuItem itmHorizontal;
        private System.Windows.Forms.ToolStripMenuItem itmVertical;
        private System.Windows.Forms.ToolStripMenuItem itmArrangIcons;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem itmSaveAS;
        private System.Windows.Forms.SaveFileDialog dlgSaveAs;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pastToolStripMenuItem;
    }
}

