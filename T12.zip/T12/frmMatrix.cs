﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace T12
{
    public partial class frmMatrix : Form
    {
        int Rows, trow;
        int Cols, tcol;
        Label[,] lblCells;

        public frmMatrix(int R, int C)
        {
            InitializeComponent();
            Rows = R;
            Cols = C;
        }

        private void frmMatrix_Load(object sender, EventArgs e)
        {

        }

        private void frmMatrix_Activated(object sender, EventArgs e)
        {
            lblCells = new Label[Rows, Cols];
            this.Width = 100 + Cols * 20;
            this.Height = 100 + Rows * 20;
            for (int row = 0; row < lblCells.GetLength(0); row++)
            {
                for (int col = 0; col < lblCells.GetLength(1); col++)
                {
                    lblCells[row, col] = new Label();
                    lblCells[row, col].Size = new Size(20, 20);
                    lblCells[row, col].Location = new Point(col * 22 + 10, row * 22 + 10);
                    lblCells[row, col].BackColor = Color.White;
                    lblCells[row, col].BorderStyle = BorderStyle.FixedSingle;
                    lblCells[row, col].Show();
                    this.Controls.Add(lblCells[row, col]);
                }
            }
            trow = 0; tcol = 0;
            // tmrAnimation.Start();
        }

        private void tmrAnimation_Tick(object sender, EventArgs e)
        {
            lblCells[trow, tcol].BackColor = Color.Blue;
            if (trow < Rows - 1)
                trow++;
            else if (tcol < Cols - 1)
            {
                tcol++;
                trow = 0;
            }
            else
                tmrAnimation.Stop();

        }

        private void frmMatrix_Click(object sender, EventArgs e)
        {
            int count = 0;
            Random rnd = new Random();
            //for (int row = 0; row < lblCells.GetLength(0); row++)
            //{
            //    for (int col = 0; col < lblCells.GetLength(1); col++)
            //    {
            //        lblCells[row, col].BackColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
            //        Application.DoEvents();
            //        Thread.Sleep(10);
            //    }
            //}

            for (int cycle = 0; cycle < 10; cycle++)
            {
                for (int lr = cycle; lr < lblCells.GetLength(1) - cycle; lr++)
                {
                    if (count == Rows * Cols) break; else count++;
                    lblCells[cycle, lr].BackColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
                    Application.DoEvents();
                    Thread.Sleep(10);
                }
                for (int ud = cycle + 1; ud < lblCells.GetLength(0) - cycle - 1; ud++)
                {
                    if (count == Rows * Cols) break; else count++;
                    lblCells[ud, lblCells.GetLength(1) - cycle - 1].BackColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
                    Application.DoEvents();
                    Thread.Sleep(10);
                }
                for (int rl = lblCells.GetLength(1) - cycle - 1; rl >= cycle; rl--)
                {
                    if (count == Rows * Cols) break; else count++;
                    lblCells[lblCells.GetLength(0) - cycle - 1, rl].BackColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
                    Application.DoEvents();
                    Thread.Sleep(10);
                }
                for (int du = lblCells.GetLength(0) - cycle - 2; du >= cycle + 1; du--)
                {
                    if (count == Rows * Cols) break; else count++;
                    lblCells[du, cycle].BackColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
                    Application.DoEvents();
                    Thread.Sleep(10);
                }
                
            }

        }
    }
}
